//
//  AppDelegate.h
//  CoreImageFun
//
//  Created by chenjiang on 15/11/28.
//  Copyright © 2015年 chenjiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

